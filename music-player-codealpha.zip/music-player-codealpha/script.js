const songs = [
    {
        title: "Believer",
        artist: "Imagine Dragons",
        src: "/Imagine Dragons - Believer (Lyrics)(M4A_128K).m4a",
        image: "https://plus.unsplash.com/premium_vector-1682269519328-193f6c0863b4?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NzV8fG11c2ljfGVufDB8fDB8fHww"
    },
    {
        title: "Right Now Na Na Na",
        artist: "Akon",
        src: "/Akon - Right Now Na Na Na (Lyrics)(M4A_128K).m4a",
        image: "https://plus.unsplash.com/premium_vector-1715426360455-81840bb78590?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTU0fHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D"
    },
    {
        title: "Unstoppable",
        artist: "Sia",
        src: "/Sia - Unstoppable (Lyrics)(M4A_128K).m4a",
        image: "https://plus.unsplash.com/premium_vector-1718218066405-5575974ed485?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTQyfHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D"
    },
    {
        title: "Shape of You",
        artist: "Ed Sheeran",
        src: "/Ed Sheeran - Shape of You (Official Music Video)(M4A_128K).m4a",
        image: "https://plus.unsplash.com/premium_vector-1716916030013-c4dbc1c55d65?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTY0fHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D"
    }
    // Add more song objects if needed
];

let currentSongIndex = 0;
let progress = document.getElementById("progress");
let song = document.getElementById("audio-player");
let ctrlIcon = document.getElementById("ctrlIcon");
let songTitle = document.getElementById("song-title");
let songArtist = document.getElementById("song-artist");
let albumArt = document.getElementById("album-art");
let musicPlayer = document.querySelector(".music-player");
let currentTimeDisplay = document.getElementById("current-time");
let totalTimeDisplay = document.getElementById("total-time");

// Function to load a song
function loadSong(index) {
    songTitle.textContent = songs[index].title;
    songArtist.textContent = songs[index].artist;
    song.src = songs[index].src;
    albumArt.src = songs[index].image;
    song.onloadedmetadata = function() {
        progress.max = song.duration;
        progress.value = song.currentTime;
        updateTimeDisplays(); // Update time displays when song loads
    };
}

// Play/Pause function
function playPause() {
    if (ctrlIcon.classList.contains("fa-pause")) {
        song.pause();
        ctrlIcon.classList.remove("fa-pause");
        ctrlIcon.classList.add("fa-play");
    } else {
        song.play();
        ctrlIcon.classList.add("fa-pause");
        ctrlIcon.classList.remove("fa-play");
    }
}

// Next and Previous song functionality
document.getElementById("next").addEventListener("click", () => {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    loadSong(currentSongIndex);
    song.play();
    ctrlIcon.classList.add("fa-pause");
    ctrlIcon.classList.remove("fa-play");
});

document.getElementById("prev").addEventListener("click", () => {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    loadSong(currentSongIndex);
    song.play();
    ctrlIcon.classList.add("fa-pause");
    ctrlIcon.classList.remove("fa-play");
});

// Update progress and time displays
setInterval(() => {
    if (!song.paused) {
        progress.value = song.currentTime;
        updateTimeDisplays();
    }
}, 500);

progress.oninput = function() {
    song.currentTime = progress.value;
    if (song.paused) {
        song.play();
        ctrlIcon.classList.add("fa-pause");
        ctrlIcon.classList.remove("fa-play");
    }
};

// Function to format time in mm:ss
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
}

// Update time displays
function updateTimeDisplays() {
    currentTimeDisplay.textContent = formatTime(song.currentTime);
    totalTimeDisplay.textContent = formatTime(song.duration);
}

// Function to rotate background images
function rotateBackgroundImages() {
    const backgroundImages = [
        'https://plus.unsplash.com/premium_vector-1724165792459-8649ad7b55fc?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTcwfHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D',
        'https://plus.unsplash.com/premium_vector-1721811531964-f7f7ee9ca78d?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTcyfHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D',
        'https://plus.unsplash.com/premium_vector-1705678100765-4110a983e9b2?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTc0fHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D',
         'https://plus.unsplash.com/premium_vector-1720522634660-03c4941e90b9?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTc1fHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D',
         'https://plus.unsplash.com/premium_vector-1721838787436-4a0665a78a5d?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTg5fHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D',
         'https://plus.unsplash.com/premium_vector-1723516983172-f466c28f9222?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTkyfHxtdXNpY3xlbnwwfHwwfHx8MA%3D%3D'

    ];

    let imageIndex = 0;
    setInterval(() => {
        console.log(`Changing background to: ${backgroundImages[imageIndex]}`); // Log the URL
        musicPlayer.style.backgroundImage = `url(${backgroundImages[imageIndex]})`;
        imageIndex = (imageIndex + 1) % backgroundImages.length;
    }, 2000); // Change image every 2 seconds
}
document.getElementById('list-button').addEventListener('click', function() {
    const playlist = document.getElementById('playlist');
    if (playlist.style.display === 'none' || playlist.style.display === '') {
        playlist.style.display = 'block';
    } else {
        playlist.style.display = 'none';
    }
});

function playSong(songPath, songTitle, songArtist) {
    const audioPlayer = document.getElementById('audio-player');
    audioPlayer.src = songPath;
    document.getElementById('song-title').innerText = songTitle;
    document.getElementById('song-artist').innerText = songArtist;
    audioPlayer.play();
    document.getElementById('ctrlIcon').classList.replace('fa-play', 'fa-pause');
}

function playPause() {
    const audioPlayer = document.getElementById('audio-player');
    const ctrlIcon = document.getElementById('ctrlIcon');

    if (audioPlayer.paused) {
        audioPlayer.play();
        ctrlIcon.classList.replace('fa-play', 'fa-pause');
    } else {
        audioPlayer.pause();
        ctrlIcon.classList.replace('fa-pause', 'fa-play');
    }
}

// Call the function to start background image rotation
rotateBackgroundImages();
